---
name: copy7-editor
description: Set up this workspace or edit and revise Shopee affiliate videos, Shorts, and Reels using supplied footage, images, and narration. Use for start, edit this, captions, revision notes, and final exports.
---

Read `.agents/skills/copy7-editor/SKILL.md` from the repository root and follow that shared workflow. It is the canonical editing skill. Read root `AGENTS.md` too. Use root-relative paths, and run engine commands from `kit/` when instructed.
